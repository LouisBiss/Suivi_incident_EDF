<?php
$db = mysqli_connect("localhost","root","","edf_suivi_panne");

if(!$db)
{
    die("Connection failed: " . mysqli_connect_error());
}

?>
?>