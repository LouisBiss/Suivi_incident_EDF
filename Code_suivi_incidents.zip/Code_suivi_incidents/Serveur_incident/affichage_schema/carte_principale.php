<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="main.css">

</head>
<body>
<div class="TITRE">
    <p class="text_tire">RESEAU HTA ST MARTIN<p>
</div>

<!-- Boutons vers sous schéma-->

<div class="depart">
    <a href="depart_Baie_Nettle.php">
    <Button class="button1" type="submit" ><span>Baie Nettle</span></input>
    </a>
    <a href="depart_Baie_Orientale.php">
    <Button class="button2" type="submit" ><span>Baie Orientale</span></input>
    </a>
    <a href="depart_Grand_Case.php">
    <Button class="button8" type="submit" ><span>Terres Basses</span></input>
    </a>
    <a href="depart_Hope_Estate.php">
    <Button class="button3" type="submit" ><span>Grand case</span></input>
    </a>
    <a href="depart_la_Savane.php">
    <Button class="button4" type="submit" ><span>Hope Estate</span></input>
    </a>
    <a href="depart_Saint_James.php">
    <Button class="button5" type="submit" ><span>La Savane</span></input>
    </a>
    <a href="depart_Spring.php">
    <Button class="button6" type="submit" ><span>Saint James</span></input>
    </a>
    <a href="depart_Terres_Basses.php">
    <Button class="button7" type="submit" ><span>Spring</span></input>
    </a>
    
</div>

<!--affichage pdf -->

<div class="schema">
    <embed src="../Images/Depart HTA/HTA st-martin.pdf" alt="">
</div>
<style>
embed{
     width:100%;
     height:30rem;
 }
 
</style>






</body>
</html>
